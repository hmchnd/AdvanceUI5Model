sap.ui.define([
	"accenture/demo/test/unit/controller/App.controller"
], function () {
	"use strict";
});